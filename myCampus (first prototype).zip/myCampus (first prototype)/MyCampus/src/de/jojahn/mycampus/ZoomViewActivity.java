package de.jojahn.mycampus;

import android.app.Activity;
import android.graphics.Point;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageButton;

public class ZoomViewActivity extends Activity implements OnGestureListener {	
	private static final String TAG = "ZoomViewActivity";
	
	private GestureDetector mGestureDetector;	
	
	private static ImageButton mButtonPlus;
	private static ImageButton mButtonMinus;
	
	private Point mScrollOffset = new Point(0, 0);	
	private Point mMapSize 		= new Point(960, 588);
	private Point mWindowSize 	= new Point();
	
	private boolean mIsZoomed = false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {		
		super.onCreate(savedInstanceState);	
		
		mGestureDetector = new GestureDetector(this);	
		
		Display display = getWindowManager().getDefaultDisplay(); 
		mWindowSize.set(display.getWidth(), display.getHeight());
		Log.w(TAG, "X: " + mWindowSize.x);
		Log.w(TAG, "Y: " + mWindowSize.y);
	}

	public void initZoomButtons() {			
		mButtonPlus		= (ImageButton) findViewById(R.id.btn_plus);
		mButtonMinus	= (ImageButton) findViewById(R.id.btn_minus);
		
		mButtonMinus.setEnabled(false);
	}
	
	public Point getMapSize() {
		return mMapSize;
	}
	
	public Point getWindowSize() {
		return mWindowSize;
	}
	
	public Point getScrollOffset() {
		return mScrollOffset;
	}
	
	public boolean getZoomState() {
		return mIsZoomed;
	}
		
	// Override this method
	public boolean itemClicked(float x, float y) {
		// ...
		return false;
	}				
	
	// Override this method
	public void onItemClicked() {		
		// ...
	}
	
	// Override this method
	public void render() {
		// ...		
	}
	
	// Switch the zoom state (and handle zoom buttons)
	private void onZoom(View v1, View v2) {
		mIsZoomed = !mIsZoomed;			
		render();
		
		v1.setEnabled(false);
		v2.setEnabled(true);
	}	
	
	// ButtonClickEvent : ZoomUpButton
	public void onPlusClicked(View view) {
		onZoom(mButtonPlus, mButtonMinus);
	}
	
	// ButtonClickEvent : ZoomDownButton
	public void onMinusClicked(View view) {
		onZoom(mButtonMinus, mButtonPlus);
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {		
		return mGestureDetector.onTouchEvent(event);		
	}	
	
	@Override
	public boolean onDown(MotionEvent e) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
			float velocityY) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void onLongPress(MotionEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
		if(mIsZoomed){			
			mScrollOffset.x -= distanceX;			
			mScrollOffset.y -= distanceY;
	    	
	    	if (mScrollOffset.x > 0) 
	    		mScrollOffset.x = 0;
	        else if (mScrollOffset.x < - mMapSize.x + mWindowSize.x)
	        	mScrollOffset.x = - mMapSize.x + mWindowSize.x;		        
	        if (mScrollOffset.y > 0)
	        	mScrollOffset.y = 0;
	        else if (mScrollOffset.y < - mMapSize.y + mWindowSize.y) 
	        	mScrollOffset.y = - mMapSize.y + mWindowSize.y;	    
	        
	        render();
		}	
		return false;
	}

	@Override
	public void onShowPress(MotionEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean onSingleTapUp(MotionEvent e) {
		float x = e.getX();
		float y = e.getY() - 26; 
		if (mIsZoomed == false) {
			if (itemClicked(x * ((float) mMapSize.x / (float) mWindowSize.x), y * ((float) mMapSize.y / (float) mWindowSize.y))) { 		
				onItemClicked();									
			}
		} else {
			if (itemClicked(x - mScrollOffset.x, y - mScrollOffset.y)) { 		
				onItemClicked();					
			}
		}	
		Log.w(TAG, "X: " + e.getX());
		Log.w(TAG, "Y: " + e.getY());
		return false;		
	}	
}
