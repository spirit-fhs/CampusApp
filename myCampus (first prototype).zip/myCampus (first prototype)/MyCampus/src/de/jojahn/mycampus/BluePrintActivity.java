package de.jojahn.mycampus;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;
import de.jojahn.mycampus.Building.Room;

public class BluePrintActivity extends ZoomViewActivity {		
	private static final String TAG = "BluePrintActivity";
	
	private ViewGroup mContainer;	
	private PathView mPathView;
	private ViewFlipper mTextFlipper;
	private ViewFlipper mImageFlipper;			
	
	private static ImageButton mUpStairs;
	private static ImageButton mDownStairs;	
	
	private static Building mBuilding;
	private static String mSearchedRoom;	
	
	private int mCurrentFloor = 0;	
	private Room mCurrentRoom = null;	
	
	private PointF mFactor;
   
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);     
        
        setContentView(R.layout.blueprint_activity);   
        
        mContainer 		= (ViewGroup) 	findViewById(R.id.container);
        mTextFlipper	= (ViewFlipper) findViewById(R.id.text_flipper);
        //mImageFlipper	= (ViewFlipper) findViewById(R.id.image_flipper); 
        mImageFlipper	= new ViewFlipper(this); 
              
        mUpStairs 		= (ImageButton) findViewById(R.id.btn_up_stairs);       
        mDownStairs 	= (ImageButton) findViewById(R.id.btn_down_stairs);
              
        mDownStairs.setEnabled(false);        
        
        // Initialize zoom buttons from ZoomViewActivity class
		initZoomButtons();	
        
        JsonFileHandler jfh = new JsonFileHandler(this);
		mBuilding = jfh.parseJSONBuilding(specifyExtras(getIntent().getExtras().getString("id")));
        
        // Add floors to the Text- and the ImageFlipper
        for (int i = 0; i < mBuilding.getNumberOfFloors(); i++) {        	
        	ImageView imageView = new ImageView(this);
        	imageView.setBackgroundResource(mBuilding.getFloorplanAtIndex(i));	
        	
        	mImageFlipper.addView(imageView); 
        	
        	TextView textView = new TextView(this);
        	textView.setText(mBuilding.getFloorDescriptions(i));        	
        	textView.setTextColor(Color.WHITE);
        	textView.setShadowLayer(1.2f, 1.2f, 1.2f, Color.parseColor("#333333"));
        	textView.setTypeface(null, Typeface.BOLD);
        	textView.setGravity(Gravity.CENTER_HORIZONTAL);
        	
        	mTextFlipper.addView(textView);          	
        }            
        
        mContainer.addView(mImageFlipper);   
        
        mFactor = new PointF(getMapSize().x / getWindowSize().x, getMapSize().y / (getWindowSize().y - 26));
        
        // Add an new PathView to the ViewGroup    
        mPathView = new PathView(this);
        mContainer.addView(mPathView);   
        
        // A room was searched
        if (mSearchedRoom != null) flipToSearchedRoom();		
    }    
    
    // Inner PathView class
    private class PathView extends View {
    	private Paint mPaint;
    	private Path mPath;      	
    	private float mPhase;     	
    	private int mColor = Color.CYAN;
    	
    	public PathView(Context context) {
    		super(context);    		
    		
    		mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    		mPaint.setStyle(Paint.Style.STROKE);
    		mPaint.setStrokeWidth(3);    	   		
    		
    		setPath(); 		
    	}
    	
    	@Override
		protected void onDraw(Canvas canvas) {				
			mPhase += 1;
			invalidate();			
			
			mPaint.setColor(mColor);
			mPaint.setPathEffect(new DashPathEffect(new float[] {5, 2, 5, 2}, mPhase));
			canvas.drawPath(mPath, mPaint); 
		}    	    	
    	
    	private void setPath() {    		
    		if (mCurrentRoom != null) mPath = makePath(mCurrentRoom, mFactor);
    		else mPath = new Path();     		
    	}
    	
    	private void resetPath() {
    		mPath.reset();
    		mCurrentRoom = null;    
    	}    	 

		// Build the room representing Path
    	public Path makePath(Room r, PointF factor) {  
    		Path p = new Path();
    		
    		p.moveTo(r.getPointAtIndex(0).x / factor.x, r.getPointAtIndex(0).y / factor.y);    		
    		
    		for (Point i : r.getPoints()) {      			
    			p.lineTo(i.x / factor.x, i.y / factor.y);
    		}    		
    		p.lineTo(r.getPointAtIndex(0).x / factor.x, r.getPointAtIndex(0).y / factor.y);
    		
    		return p;
    	}
    }
    
    // Flip view and show path for searched room
    private void flipToSearchedRoom() {        	
    	while (Integer.valueOf(String.valueOf(mSearchedRoom.charAt(1))) !=  mCurrentFloor) {
    		mCurrentFloor += 1;            		
        	mDownStairs.setEnabled(true);          	
    		if (mCurrentFloor == mBuilding.getNumberOfFloors() - 1) mUpStairs.setEnabled(false);
        			
    		mImageFlipper.showNext();
    		mTextFlipper.showNext(); 					
    	}    		
    	mCurrentRoom = mBuilding.getRoom(mSearchedRoom);    		
		mPathView.setPath();			
		Toast.makeText(this,"" + mCurrentRoom.getName(),Toast.LENGTH_SHORT).show();		
    }
    
    // Specify intent extras 
    private String specifyExtras(String s) {
    	// RoomSearchActivity intent
    	if (s.length() > 1) {
    		// RoomSearchActivity intent
    		mSearchedRoom = s;    		
    		return String.valueOf(s.charAt(0));
    	} else {
    		// MapActivity intent
    		mSearchedRoom = null;
    		return s;
    	}    	
    }      
    
    @Override
	public boolean itemClicked(float x, float y) {
    	// Check whether a room was touched or not
    	for (Room r: mBuilding.getRooms()) {
			if (r.getFloor() == mCurrentFloor && r.getRect().contains((int) x, (int) y)) {
				mCurrentRoom = r; 
				return true;
			}
		}    
    	mPathView.resetPath();
		return false;
	}

	@Override
	public void onItemClicked() {
		mPathView.setPath();	
		
		Toast.makeText(this,"" + mCurrentRoom.getName(),Toast.LENGTH_SHORT).show();				
	}	
    
    @Override
	public void render() {    	
    	if(getZoomState()) {
    		mImageFlipper.getChildAt(mCurrentFloor - 0).layout(getScrollOffset().x, getScrollOffset().y, getScrollOffset().x + getMapSize().x, getScrollOffset().y + getMapSize().y);
    		mPathView.layout(getScrollOffset().x, getScrollOffset().y, getScrollOffset().x + getMapSize().x, getScrollOffset().y + getMapSize().y);
		} else {
			mImageFlipper.getChildAt(mCurrentFloor - 0).layout(0, 0, getWindowSize().x, getWindowSize().y - 26);
			mPathView.layout(0, 0, getWindowSize().x, getWindowSize().y);
		}		
	}   

	@Override
	public void onPlusClicked(View view) {
		mFactor.set(1, 1);
		mPathView.setPath();
		mPathView.mPaint.setStrokeWidth(5);
		super.onPlusClicked(view);
	}

	@Override 
	public void onMinusClicked(View view) {
		//mFactor.set(getMapSize().x / getWindowSize().x, getMapSize().y / getWindowSize().y);
		mFactor.set(getMapSize().x / getWindowSize().x, getMapSize().y / (getWindowSize().y - 26));
		mPathView.setPath();
		mPathView.mPaint.setStrokeWidth(3);
		super.onMinusClicked(view); 
	}

	// ButtonClickEvent : UpStairsButton
    public void onUpStairsClicked(View view) { 
    	if (mCurrentFloor == mBuilding.getNumberOfFloors() - 1) return;
    	
    	mCurrentFloor += 1;
    	
    	mDownStairs.setEnabled(true);    	 		
		if (mCurrentFloor == mBuilding.getNumberOfFloors() - 1) mUpStairs.setEnabled(false);
    	
		// Play ViewFlipper animation
		mImageFlipper.setInAnimation(AnimationUtils.loadAnimation(this, R.anim.push_left_in));
	    mImageFlipper.setOutAnimation(AnimationUtils.loadAnimation(this, R.anim.push_left_out));           
	    mImageFlipper.showNext();
	    
	    // Play TextView animation
	    mTextFlipper.setInAnimation(AnimationUtils.loadAnimation(this, R.anim.push_up_in));		
	    mTextFlipper.setOutAnimation(AnimationUtils.loadAnimation(this, R.anim.push_up_out));
		mTextFlipper.showNext(); 
		
		mPathView.resetPath();  	
		if (getZoomState()) onMinusClicked(view);
    }
  
    // ButtonClickEvent : DownStairsButton
    public void onDownStairsClicked(View view) {
    	if (mCurrentFloor == 0) return;
    	
    	mCurrentFloor -= 1;
    	
    	mUpStairs.setEnabled(true); 
    	if (mCurrentFloor == 0) mDownStairs.setEnabled(false);
    	
    	// Play ViewFlipper animation
    	mImageFlipper.setInAnimation(AnimationUtils.loadAnimation(this, R.anim.push_right_in));
    	mImageFlipper.setOutAnimation(AnimationUtils.loadAnimation(this, R.anim.push_right_out));           
    	mImageFlipper.showPrevious();
		
		// Play TextView animation
        mTextFlipper.setInAnimation(AnimationUtils.loadAnimation(this, R.anim.push_up_in));	
        mTextFlipper.setOutAnimation(AnimationUtils.loadAnimation(this, R.anim.push_up_out));
        mTextFlipper.showPrevious();
        
		mPathView.resetPath();
		if (getZoomState()) onMinusClicked(view);
    }          

	@Override
	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,	float velocityY) {
		// onFling triggers only for zoom out state 
		if(!getZoomState()){
			// Fling left	
			if(e1.getX() > e2.getX() + 100 && velocityX < -1000) onUpStairsClicked(this.findViewById(R.id.btn_up_stairs));
			
			// Fling right		
			if(e1.getX() < e2.getX() - 100 && velocityX > 1000) onDownStairsClicked(this.findViewById(R.id.btn_down_stairs));
			
		}		
		
		return false;
	}	
}