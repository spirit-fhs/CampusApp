package de.jojahn.mycampus;

import java.util.ArrayList;

import android.graphics.Point;
import android.graphics.Rect;

public class Building {
	private static final String TAG = "BuildingClass";
	
	private String mId;
	private String mName;
	private int mNumberOfFloors;
	private int mNumberOfRooms;	
	
	private static ArrayList<Integer> mFloorPlan;	
	
	private static ArrayList<Room> mRoom;	
	
	public Building() {
		mFloorPlan = new ArrayList<Integer>();
		mRoom = new ArrayList<Room>();
	}	
	
	// Inner Room class
	public static class Room  {
		private String mName;		
		private Rect mRect;
		private Point[] mPoint;
		
		public Room() {
			mRect = new Rect();				
		}
		
		// Calculate Rect bounds from Points
		public void initRect() {			
			Point min = new Point(1000, 1000);
			Point max = new Point(0, 0);
			
			for (Point i : mPoint) {
				if (i.x < min.x) min.x = i.x;
				if (i.y < min.y) min.y = i.y;
				if (i.x > max.x) max.x = i.x;
				if (i.y > max.y) max.y = i.y;
			}
			mRect.set(min.x, min.y, max.x, max.y);				
		}
		
		public void setName(String name) {
			mName = name;			
		}
		
		public String getName() {
			return mName;
		}
		
		// Convert ArrayList of Integers to Array of Points
		public void setPoint(ArrayList<Integer> point) {
			int length = (int) (point.size() / 2);			
			mPoint = new Point[length];			
			
			for (int i = 0; i < length; i++) {
				mPoint[i] = new Point();				
				mPoint[i].x = point.get(i * 2);				
				mPoint[i].y = point.get((i * 2) + 1);			
			}					
		}
		
		public Point[] getPoint() {
			return mPoint;
		}
		
		public int getFloor() {
			return Integer.valueOf(String.valueOf(mName.charAt(1)));			
		}
		
		public Rect getRect() {
			return mRect;
		}
		
		public Point getPointAtIndex(int index) {
			return mPoint[index];
		}
		
		public Point[] getPoints() {
			return mPoint;
		}
		
		public int getPointsLength() {
			return mPoint.length;
		}
	}
	
	public void setId(String id) {
		mId = id;
	}
	
	public String getName() {
		return mName;
	}
	
	public void setName(String name) {
		mName = name;
	}
	
	public String getId() {
		return mId;
	}
	
	public void setNumberOfFloors(int i) {
		mNumberOfFloors = i;
	}
	
	public int getNumberOfFloors() {
		return mNumberOfFloors;
	}
	
	public void setNumberOfRooms(int i) {
		mNumberOfRooms = i;
	}
	
	// Calculate NumberOfFloors and NumberOfRooms
	public void initBuilding() {
		mNumberOfFloors = mFloorPlan.size();
		mNumberOfRooms = mRoom.size(); 
	}
	
	public int getNumberOfRooms() {
		return mNumberOfRooms;
	}
	
	public String getFloorDescriptions(int floor) {
		if (floor == 0) 
			return mName + ", Erdgeschoss";
		else 
			return mName + ", " + floor + ". Etage";		
	}
	
	public void addFloor(String id) throws IllegalArgumentException, SecurityException, IllegalAccessException, NoSuchFieldException {		
		mFloorPlan.add(R.drawable.class.getField(id).getInt(null));
	}
	
	public int getFloorplanAtIndex(int index) {
		return mFloorPlan.get(index);
	}
	
	public ArrayList<Integer> getFloorplans() {
		return mFloorPlan;
	}
	
	public void addRoom(Room room) {
		mRoom.add(room);
	}
	
	public Room getRoom(String name) {
		for (Room r : mRoom) {
			if (r.getName().equals(name)) return r;
		}
		return null;
	}
	
	public ArrayList<Room> getRooms() {
		return mRoom;
	}

}
