package de.jojahn.mycampus;

import java.io.InputStream;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

import android.content.Context;
import android.util.Log;
import de.jojahn.mycampus.Building.Room;
import de.jojahn.mycampus.Campus.Item;

public class JsonFileHandler {
	private static final String TAG = "JSONFileHandler";
	
	private Context mContext;		
	private Boolean mBildingFound;
	
	public JsonFileHandler(Context context) {
		mContext = context;		
		mBildingFound = false; 
	}
	
	// Parse a JSON File to CampusObject
	public Campus parseJSONCampus() {
		Campus campus = new Campus();		
		
		try {			
			//FileInputStream fis = mContext.openFileInput(mContext.getString(R.string.filename_campus));
			InputStream fis = mContext.getResources().openRawResource(R.raw.campus);
			
			byte[] buffer = new byte[fis.available()];
			while (fis.read(buffer) != -1);
			
			String jsonText = new String(buffer);
			JSONArray entries = new JSONArray(jsonText);
			
			for (int i = 0; i < entries.length(); i++) {
				JSONObject post = entries.getJSONObject(i);			 	
				
				// campus
				campus.setId(post.getString("id"));
				campus.setBitmapResource(post.getJSONArray("bitmaps").getString(0), 0);	 		
				campus.setBitmapResource(post.getJSONArray("bitmaps").getString(1), 1);	 						
				
				// items	
				for (int j = 0; j < post.getJSONArray("items").length(); j++) {				
					Item item = new Item();
					
					item.setId(post.getJSONArray("items").getJSONObject(j).getString("id"));
					item.setName(post.getJSONArray("items").getJSONObject(j).getString("name"));										
					item.setBitmap(post.getJSONArray("items").getJSONObject(j).getString("bitmap"));
					
					item.setNumberOfButtons(post.getJSONArray("items").getJSONObject(j).getInt("buttons"));	
					item.setUrl(post.getJSONArray("items").getJSONObject(j).getString("url"));	
					
					item.setButtonText(post.getJSONArray("items").getJSONObject(j).getString("buttontext"));	
					item.setText(post.getJSONArray("items").getJSONObject(j).getString("text"));
					
					int[] rect = new int[4];
					for (int k = 0; k < post.getJSONArray("items").getJSONObject(j).getJSONArray("position").length(); k++) {
						rect[k] = post.getJSONArray("items").getJSONObject(j).getJSONArray("position").getInt(k); 
					}				
					item.setRect(rect);
					campus.addItem(item);					 
				}					
			}
			fis.close();	
		} 
		catch (Exception e) {
			Log.e(TAG, e.toString());
		}
		return campus;
	}
	
	// Parse a JSON File to BuildingObject
	public Building parseJSONBuilding(String id) {
		Building building = new Building(); 		
		
		try {
			//FileInputStream fis = mContext.openFileInput(mContext.getString(R.string.filename_building));							
			InputStream fis = mContext.getResources().openRawResource(R.raw.building);
			
			byte[] buffer = new byte[fis.available()];
			while (fis.read(buffer) != -1);
			Log.e(TAG, "" + fis.read(buffer));
			
			String jsonText = new String(buffer);
			JSONArray entries = new JSONArray(jsonText);
			
			for (int i = 0; i < entries.length(); i++) {
				JSONObject post = entries.getJSONObject(i);					
				
				if (post.getString("id").equals(id)) { 
					mBildingFound = true;
				
					// building
					building.setId(post.getString("id"));
					building.setName(post.getString("name"));
					
					for (int j = 0; j < post.getJSONArray("bitmaps").length(); j++) {
						building.addFloor(post.getJSONArray("bitmaps").getString(j));  
					}					
					
					// rooms	
					for (int k = 0; k < post.getJSONArray("rooms").length(); k++) {				
						Room room = new Room();
						
						room.setName(post.getJSONArray("rooms").getJSONObject(k).getString("name"));						
						
						ArrayList<Integer> point = new ArrayList<Integer>();
						for (int l = 0; l < post.getJSONArray("rooms").getJSONObject(k).getJSONArray("point").length(); l++) {						
							point.add(post.getJSONArray("rooms").getJSONObject(k).getJSONArray("point").getInt(l)); 							
						}									
						room.setPoint(point);					
						room.initRect();
						
						building.addRoom(room);					  
					}			
				}				
			}
			// no Building with given id was found
			if (!mBildingFound) {				
				Log.e(TAG, "no building with id: " + id);				
			}
			fis.close();	
		} 
		catch (Exception e) {
			Log.e(TAG, e.toString());
		}
		// Calculate NumberOfFloors and NumberOfRooms
		building.initBuilding();
		
		return building;
	}
	
	// Parse a JSON File to RoomList
	public ArrayList<String> parseJSONRoomList() {
		ArrayList<String> roomList = new ArrayList<String>();		
		
		try {
			//FileInputStream fis = mContext.openFileInput(mContext.getString(R.string.filename_building));							
			InputStream fis = mContext.getResources().openRawResource(R.raw.building);
			
			byte[] buffer = new byte[fis.available()];
			while (fis.read(buffer) != -1);
			Log.e(TAG, "" + fis.read(buffer)); 
			
			String jsonText = new String(buffer);
			JSONArray entries = new JSONArray(jsonText);
			
			for (int i = 0; i < entries.length(); i++) {
				JSONObject post = entries.getJSONObject(i);						
				
				// rooms	
				for (int j = 0; j < post.getJSONArray("rooms").length(); j++) {				
										
					roomList.add(post.getJSONArray("rooms").getJSONObject(j).getString("name"));	
				}			
			}			
			fis.close();	
		} 
		catch (Exception e) {
			Log.e(TAG, e.toString());
		}		
		return roomList;
	}
}
