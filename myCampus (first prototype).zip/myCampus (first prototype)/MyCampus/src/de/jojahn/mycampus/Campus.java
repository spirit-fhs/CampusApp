package de.jojahn.mycampus;

import java.util.ArrayList;

import android.graphics.Rect;
import android.text.Html;

public class Campus {
	private static final String TAG = "CampusClass";
	
	private static String mId;	
	private static int[] mBitmapResource = new int[2];	
	private static ArrayList<Item> mItem;
		
	public Campus() {
		mItem = new ArrayList<Item>();
	}	
	
	// Inner Item class
	public static class Item  {
		private String mId;
		private String mName;
		private Rect mRect;			
		private int mBitmap;
		private int mNumberOfButtons;		
		private String mUrl;
		private String mButtonText;
		private CharSequence mText;
		
		public Item() {	
			mRect = new Rect();
		}				
		
		public String getId() {
			return mId;
		}	
		
		public void setId(String id) {
			mId = id;
		}
		
		public String getName() {
			return mName;
		}	
		
		public void setName(String name) {
			mName = name;
		}
		
		public Rect getRect() {
			return mRect;
		}	
		
		public void setRect(int[] i) {
			mRect.set(i[0], i[1], i[2], i[3]);
		}
		
		public int getBitmap() {
			return mBitmap;
		}	
		
		public void setBitmap(String id) throws IllegalArgumentException, SecurityException, IllegalAccessException, NoSuchFieldException {
			mBitmap = R.drawable.class.getField(id).getInt(null);
		}
		
		public int getNumberOfButtons() {
			return mNumberOfButtons;
		}	
		
		public void setNumberOfButtons(int i) {
			mNumberOfButtons = i;
		}
		
		public String getUrl() {
			return mUrl;
		}	
		
		public void setUrl(String url) {
			mUrl = url;
		}
		
		public String getButtonText() {
			return mButtonText;
		}	
		
		public void setButtonText(String text) {
			mButtonText = text;
		}
		
		public CharSequence getText() {
			return mText;
		}
		
		public void setText(String text) {
			mText = Html.fromHtml(text);
		}
	}
	
	public void setId(String id) {
		this.mId = id;
	}	
	
	public String getId() {
		return mId;
	}
	
	public void addItem(Item item) {
		mItem.add(item);
	}
	
	public int getBitmapResourceAtIndex(int index) {
		return mBitmapResource[index];
	}	
	
	public void setBitmapResource(String id, int index) throws IllegalArgumentException, SecurityException, IllegalAccessException, NoSuchFieldException {
		this.mBitmapResource[index] = R.drawable.class.getField(id).getInt(null);
	}	
	
	public Item getItemAtIndex(int index) {
		return mItem.get(index);
	}
	
	public ArrayList<Item> getItems() {
		return mItem;
	}

}
