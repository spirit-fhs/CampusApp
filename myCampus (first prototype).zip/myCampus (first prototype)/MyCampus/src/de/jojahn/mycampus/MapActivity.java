package de.jojahn.mycampus;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Point;
import android.graphics.RectF;
import android.graphics.drawable.AnimationDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import de.jojahn.mycampus.Campus.Item;

public class MapActivity extends ZoomViewActivity {
	private static final String TAG = "MapActivity";
	
	private ViewGroup mContainer;	
	private FrameLayout mMapView;
	private TextView mTitle;
	
	public ImageView mLayerAnim;
	public ImageView mLayerGeo;
	public ImageView mLayerBack;	
	
	private static Button mDialogButton1; 
	private static Button mDialogButton2; 
	private static CheckBox mGPSBox;	
	
	private Campus mCampus;				
	private Item mCurrentItem = null;		
	private Dialog mDialog;
	
	// GPS constant: pixel per meter
	private float PPM = 0;		
	// GPS constant: initial map rotation
	private float IMR = 0; 
	
	private boolean mGPS = false;	
	
	Location mCenterLocation;	
	Location mUserLocation;	
	
	LocationManager locationManager;
	LocationListener locationListener;	
	
	private RectF mRectfCenterLocation;	
	private RectF mRectfUserLocation;
	
	private Point mPointUserLocation = new Point(0, 0);
	private Matrix mMatrixUserLocation = new Matrix();	
	
	private int mGeoSize;	
	private boolean mUserOnMap = false;	
	private AnimationDrawable mAnimationGeo;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {		
		super.onCreate(savedInstanceState);	
		
		setContentView(R.layout.map_activity);	
		
		mMapView 	= new FrameLayout(this);		
		mContainer 	= (ViewGroup) 	findViewById(R.id.container);			
		mTitle		= (TextView)	findViewById(R.id.title_text); 
		mGPSBox 	= (CheckBox) 	findViewById(R.id.btn_gps);
		
		mLayerBack 	= new ImageView(this);
		mLayerGeo 	= new ImageView(this);
		mLayerAnim 	= new ImageView(this);
		
		mMapView.addView(mLayerBack);	
		mMapView.addView(mLayerGeo);
		mMapView.addView(mLayerAnim);
		
		mMapView.setFocusable(true);	
		
		// Initialize zoom buttons from ZoomViewActivity class
		initZoomButtons();		
		
		// Add an new MapView to the view group   		
        mContainer.addView(mMapView, 0);  
        
        
        
        JsonFileHandler jfh = new JsonFileHandler(this);
		mCampus = jfh.parseJSONCampus();	
		
		mTitle.setText(mCampus.getId());
		
		mLayerBack.setBackgroundResource(mCampus.getBitmapResourceAtIndex(0));	
				
		mAnimationGeo = (AnimationDrawable) getResources().getDrawable(R.drawable.animation_campus_geo);
		mLayerGeo.setImageDrawable(mAnimationGeo); 
		mLayerGeo.setVisibility(View.INVISIBLE);				
		
        // Initialize Dialog
		mDialog = new Dialog(this); 
        mDialog.setContentView(R.layout.map_dialog);  
        
        mDialogButton1 = (Button) mDialog.findViewById(R.id.btn_dialog_1);
        mDialogButton1.setOnClickListener(onButton1Clicked);
        mDialogButton2 = (Button) mDialog.findViewById(R.id.btn_dialog_2);
        mDialogButton2.setOnClickListener(onButton2Clicked);
        Button btn3 = (Button) mDialog.findViewById(R.id.btn_dialog_3);
        btn3.setOnClickListener(onButton3Clicked);
        
        // Initialize GPS constants
		PPM = Float.valueOf(getResources().getString(R.string.pixel_per_meter));
		IMR = Float.valueOf(getResources().getString(R.string.initial_map_rotation));
		
		mGeoSize = (int) ((BitmapFactory.decodeResource(getResources(), R.drawable.ic_maps_indicator_current_position_anim1).getWidth()) / 2);
		mRectfCenterLocation = new RectF(0, 0, getMapSize().x, getMapSize().y);	
        mRectfUserLocation = new RectF(mRectfCenterLocation);        
       
        // Initialize Locations
        mCenterLocation = new Location(LocationManager.GPS_PROVIDER);
        mCenterLocation.setLatitude(Double.valueOf(getResources().getString(R.string.center_latitude))); 
        mCenterLocation.setLongitude(Double.valueOf(getResources().getString(R.string.center_longitude)));             
        
        mUserLocation = new Location(LocationManager.GPS_PROVIDER);
        mUserLocation.setLatitude(50.717235); 
        mUserLocation.setLongitude(10.464531);        
       
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        locationListener = new LocationListener() {			
			@Override
			public void onStatusChanged(String provider, int status, Bundle extras) {
				// TODO Auto-generated method stub
			}
			
			@Override
			public void onProviderEnabled(String provider) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onProviderDisabled(String provider) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onLocationChanged(Location location) {
				//mMapView.transformGeo(mCenterLocation.distanceTo(mUserLocation), mCenterLocation.bearingTo(mUserLocation));
				transformGeo(mCenterLocation.distanceTo(location), mCenterLocation.bearingTo(location));
				render();				
			}
		};	
	}		
			
	public void setGeoAnimation(boolean b) {
		if (b) mAnimationGeo.start();
		else mAnimationGeo.stop();
	}
	
	public void setGeoVisibility(boolean b) {
		if (b) mLayerGeo.setVisibility(View.VISIBLE);
		else mLayerGeo.setVisibility(View.INVISIBLE);
	}
	
	// Calculate new user location
	public boolean transformGeo(float distance, float bearing) {
		if (distance > 0) {
			// translation: distance to the center of the screen 
			mMatrixUserLocation.setTranslate(0, - (distance * PPM));
			
			// rotation:  angle to the center of the screen 
			mMatrixUserLocation.postRotate(bearing - IMR, mRectfCenterLocation.centerX(), mRectfCenterLocation.centerY());						
			
			// transform user location 
			mMatrixUserLocation.mapRect(mRectfUserLocation, mRectfCenterLocation);
			mPointUserLocation.set((int) mRectfUserLocation.centerX(), (int) mRectfUserLocation.centerY());
			
			// check whether user is on the campus
			if (mPointUserLocation.x > 0 && mPointUserLocation.x < getMapSize().x && mPointUserLocation.y > 0 && mPointUserLocation.y < getMapSize().y) {
				mUserOnMap = true;
			} else {
				mUserOnMap = false;
			}				
			return true;
		}
			return false;			
	}

	@Override
	public void onLongPress(MotionEvent e) {
		// TODO Auto-generated method stub		
		AnimationDrawable anim = (AnimationDrawable) getResources().getDrawable(R.drawable.animation_campus_night);
		mLayerAnim.setImageDrawable(anim);
		anim.start();
		mLayerBack.setBackgroundResource(R.drawable.image_campus_night);
		render();
	}	
		
	// ButtonClickEvent : Button1 (web link)
	private View.OnClickListener onButton1Clicked = new OnClickListener() {			
		@Override
		public void onClick(View v) {			
			Intent i = new Intent(Intent.ACTION_VIEW);
			i.setData(Uri.parse(mCurrentItem.getUrl()));
			startActivity(i);
		}
	};		
	
	// ButtonClickEvent : Button2 (blueprint)
	private View.OnClickListener onButton2Clicked = new OnClickListener() {			
		@Override
		public void onClick(View v) {				
			Intent intent = new Intent(getBaseContext(), BluePrintActivity.class);
			intent.putExtra("id", mCurrentItem.getId());
	        startActivity(intent); 	  
		}
	};		
		
	// ButtonClickEvent : Button3 (exit)
	private View.OnClickListener onButton3Clicked = new OnClickListener() {			
		@Override
		public void onClick(View v) {			
			mDialog.cancel();   
		}
	};			
	
	@Override	
	public boolean itemClicked(float x, float y) {
		// Check whether a item was touched or not
		for (Item i: mCampus.getItems()) {			
			if (i.getRect().contains((int) x, (int) y)) {
				mCurrentItem = i; 
				return true;
			}
		}    		
		return false;		
	}

	@Override	
	public void onItemClicked() {
		// Create the Dialog content
		if (mCurrentItem.getUrl() == null) {
			Toast.makeText(getBaseContext(),"" + mCurrentItem.getName(),Toast.LENGTH_SHORT).show();
		} else {
			ScrollView scroll = (ScrollView) mDialog.findViewById(R.id.scroll_dialog);
			scroll.scrollTo(0, 0);
			
			ImageView image = (ImageView) mDialog.findViewById(R.id.image_dialog);
			image.setBackgroundResource(mCurrentItem.getBitmap()); 				
			
			TextView text = (TextView) mDialog.findViewById(R.id.text_dialog);			
			text.setText(mCurrentItem.getText());
			
			mDialogButton1.setText(mCurrentItem.getButtonText());
			if (mCurrentItem.getNumberOfButtons() == 1) mDialogButton2.setVisibility(View.GONE);
			else mDialogButton2.setVisibility(View.VISIBLE); 
			
			mDialog.setTitle(mCurrentItem.getName());
			mDialog.show();
		}
	}
	
	@Override
	public void render() {
		if(getZoomState()) {
			mLayerAnim.layout(getScrollOffset().x, getScrollOffset().y, getScrollOffset().x + getMapSize().x, getScrollOffset().y + getMapSize().y);
			mLayerBack.layout(getScrollOffset().x, getScrollOffset().y, getScrollOffset().x + getMapSize().x, getScrollOffset().y + getMapSize().y);
			mLayerGeo.layout(getScrollOffset().x + mPointUserLocation.x - mGeoSize, getScrollOffset().y + mPointUserLocation.y - mGeoSize, getScrollOffset().x + mPointUserLocation.x + mGeoSize, getScrollOffset().y + mPointUserLocation.y + mGeoSize);			
		} else {
			mLayerAnim.layout(0, 0, getWindowSize().x, getWindowSize().y);
			mLayerBack.layout(0, 0, getWindowSize().x, getWindowSize().y);
			mLayerGeo.layout((int) ((mPointUserLocation.x - mGeoSize) / ((float) getMapSize().x / (float) getWindowSize().x)), (int) ((mPointUserLocation.y - mGeoSize) / ((float) getMapSize().y / (float) getWindowSize().y)), (int) ((mPointUserLocation.x + mGeoSize) / ((float) getMapSize().x / (float) getWindowSize().x)), (int) ((mPointUserLocation.y + mGeoSize) / ((float) getMapSize().y / (float) getWindowSize().y)));
		}			
	}

	// start GPS tracking
    public void startGPS() {    	
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);        
        setGeoAnimation(true);
		setGeoVisibility(true);  
        render();           
    } 
    
    // stop GPS tracking
    public void stopGPS() {    	
    	locationManager.removeUpdates(locationListener);    
    	setGeoAnimation(false);
    	setGeoVisibility(false); 
    	render();        
   }
			
	// ButtonClickEvent : GPSCheckBox
	public void onGPSClicked(View view) {		
        if (((CheckBox) view).isChecked()) {        	
        	startGPS();
        	Toast.makeText(this, "GPS on", Toast.LENGTH_SHORT).show();	
        	
        } else {      
        	stopGPS();  
        	Toast.makeText(this, "GPS off", Toast.LENGTH_SHORT).show();        	  	        	
        }              
        mGPS = !mGPS;       
	}

	@Override
	protected void onPause() {
		stopGPS();
		super.onPause();
	} 

	@Override
	protected void onResume() {
		if(mGPS) startGPS();		
		super.onResume();
	}
}
