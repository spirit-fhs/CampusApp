package de.jojahn.mycampus;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Toast;

public class RoomSearchActivity extends Activity {	

	AutoCompleteTextView mAutoTextView;
	
	ArrayList<String> mRoomList;
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        setContentView(R.layout.roomsearch_activity);
        
        // Get list of existent rooms from JSON file
        JsonFileHandler jfh = new JsonFileHandler(this);
		mRoomList = jfh.parseJSONRoomList();		

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, mRoomList);
       
        // Sort the adapter elements by name
        adapter.sort(new Comparator<String>() {
        	public int compare(String object1, String object2) {
        		return object1.compareTo(object2); 
        	}
		});
        
        mAutoTextView = (AutoCompleteTextView) findViewById(R.id.edit);
        mAutoTextView.setAdapter(adapter);           
    }
	
	// Check whether searched room exists
	private boolean roomExists(String room) {
		for (String string : mRoomList) {
			if(string.equals(room)) return true;
		}
		return false;
	}
	
	// ButtonClickEvent : SearchButton
    public void onSearchClicked(View view) {    
    	if(roomExists(mAutoTextView.getText().toString())) {
    		// Searched room exists
    		Intent intent = new Intent(this, BluePrintActivity.class);
    		intent.putExtra("id", mAutoTextView.getText().toString());
            this.startActivity(intent); 
    		//Toast.makeText(this, mAutoTextView.getText().toString() + " existiert!", Toast.LENGTH_SHORT).show();	
    	} else {
    		// Searched room doesn�t exists
    		Toast.makeText(this, "Der gesuchte Raum existiert nicht!", Toast.LENGTH_SHORT).show();	
    	}    	
    }
	
}
