package de.jojahn.mycampus;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends Activity {    
	private static final String TAG = "MainActivity";
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);     
        
        setContentView(R.layout.main_activity);           
                
        // Check whether JSOnFiles exists in the "Internal Storage" (download if necessary)
        initJSONFiles(this.getString(R.string.filename_campus), getString(R.string.url_file_campus));           
        initJSONFiles(this.getString(R.string.filename_building), getString(R.string.url_file_building));        
    }
    
    // Check whether JSOnFile exists in the "Internal Storage"      
    public void initJSONFiles(String path, String surl) {    	
        try {
        	FileInputStream fis = this.openFileInput(path);         	
        	
        	// JsonFile already exists (no Exception was thrown)           	
        	fis.close();
        	Log.w(TAG, path + " exists already");           	
        		  
    	} catch (Exception e1) { 
    		// JsonFile does not exist already (try to download it!)   		
    		Log.w(TAG, path + " does not exists");          	
    		
    		try {
            	URL url = new URL(surl);
            	HttpURLConnection c = (HttpURLConnection) url.openConnection();
            	
            	c.setRequestMethod("GET");
            	c.setDoOutput(true);   
            	c.connect();
            	
            	FileOutputStream fos;
    			fos = openFileOutput(path, this.MODE_PRIVATE); 	 				
    			
    			InputStream is = c.getInputStream();
    			
    			byte[] buffer = new byte[is.available()];        			
    			
    			while (is.read(buffer) != -1) fos.write(buffer);   			
    			
    			Log.w(TAG, path + " is downloaded");   
    			
    			fos.close();
    			is.close(); 
            } catch (Exception e2) {
            	Log.e(TAG, e2.toString());
            }   		
            
            Log.w(TAG, path + " is created"); 
    	}   
    }
    
    // ButtonClickEvent : CampusButton
    public void onCampusClicked(View view) {    		
		Intent intent = new Intent(this,MapActivity.class);
        startActivity(intent); 	  
    }
    
    // ButtonClickEvent : CampusButton
    public void onRoomSearchClicked(View view) {    			
    	Intent intent = new Intent(this,RoomSearchActivity.class);
		startActivity(intent); 
    }
}