package de.jojahn.campus;

import android.content.Context;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class TutorialHelper {	
	private Context mContext;
	
	private LinearLayout mContainer;
	
	private TextView mTextView;
	private ImageView mImageView;	
	
	public TutorialHelper(Context context, int id) {
		mContext = context;
		
		mContainer = new LinearLayout(context);		
		mTextView = new TextView(context);
		mTextView.setText("asfdsdgfsdf");
		mImageView = new ImageView(context);
	}	
	
	public void adsd () {
		mContainer.addView(mTextView);
		mContainer.addView(mImageView);
	
	}

}
