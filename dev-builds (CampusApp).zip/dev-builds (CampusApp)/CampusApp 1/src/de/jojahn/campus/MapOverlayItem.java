package de.jojahn.campus;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.OverlayItem;

public class MapOverlayItem extends OverlayItem {
	
	private int mType;
	private String[] mExtraIntent = new String[2];
	private String[] mExtraTitel = new String[2];
	
	// Constructor
	public MapOverlayItem(int type, GeoPoint point, String title, String snippet) {
		super(point, title, snippet);
		mType = type;		
	}	
		
	public void setExtra(String[] intent, String[] titel) {
		mExtraIntent = intent;
		mExtraTitel = titel;
	}
	
	public int getType() {
		return mType;
	}	
	
	public String getExtraIntent(int index) {
		return mExtraIntent[index];
	}	
	
	public String getExtraTitel(int index) {
		return mExtraTitel[index];
	}	
}
