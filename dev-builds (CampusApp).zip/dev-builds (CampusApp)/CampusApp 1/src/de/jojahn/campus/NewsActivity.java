package de.jojahn.campus;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class NewsActivity extends Activity {

	// Application context
	private Context mContext;
	
	// ListView and NewsAdapter
	private ListView mListView;
	private NewsAdapter mNewsAdapter;
	
	// News categories
	private ArrayList<String> mNewsCategories = new ArrayList<String>();
	
	// Network loading and parsing 
	private ConnectionHandler mConnectionHandler;
	private JSONParser mJSONParser;	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {		
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.news);	
		
		mContext = getApplicationContext();
		
		// ListView and NewsAdapter
		mListView = (ListView) findViewById(R.id.news_list);
		mNewsAdapter = new NewsAdapter(this);
		mListView.setAdapter(mNewsAdapter);
		
		// OnItemClickListener
		mListView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				// Send NewsListActivity intent with extra(category)				
				Intent intent = new Intent(mContext, NewsListActivity.class);
				intent.putExtra("category", mNewsCategories.get(position));
				startActivity(intent); 					
			}
		}); 
		
		// Loading network files
        mConnectionHandler = new ConnectionHandler(this, getString(R.string.type_news));
        mConnectionHandler.loadingFiles();	
        
        // Parsing network files
        mJSONParser = new JSONParser(this, getString(R.string.type_news));
        mNewsCategories = mJSONParser.parseNewsCategories();   
        mNewsCategories.add(0, getString(R.string.all_news));        
        
        // Sort ArrayList by name
        Comparator<String> comperator = new Comparator<String>() {
			@Override
			public int compare(String string1, String string2) {				
				return string1.compareToIgnoreCase(string2);
			}
		};
        Collections.sort(mNewsCategories, comperator);
	}
	
	private class NewsAdapter extends BaseAdapter {
		private Context mContext;
		
		// Constructor
		public NewsAdapter(Context context) {
            mContext = context;
        }
		
		@Override
		public int getCount() {			
			return mNewsCategories.size();
		}

		@Override
		public Object getItem(int position) {			
			return position;
		}

		@Override
		public long getItemId(int position) {			
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			TextView textView;
			if (convertView == null) {
				textView = (TextView) LayoutInflater.from(mContext).inflate(R.layout.news_category, parent, false);
            } else {
            	textView = (TextView) convertView; 
            }
			textView.setText(mNewsCategories.get(position));
            return textView;
		}		
	} 
}
