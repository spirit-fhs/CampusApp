package de.jojahn.campus;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

public class ConnectionHandler {
	private static final String TAG = "ConnectionHandler";
	
	// Context and expected type of the invoking activity
	private Context mContext;
	private String mType; 	
	
	// Constructor
	public ConnectionHandler(Context context, String type) {
		mContext = context;
		mType = type;
	}
	
	// Loading requested files
	public boolean loadingFiles() {		
		try {
			// Establish HttpUrlconnection
			//URL url = new URL("http://www.jojahn.de/news_items.txt");
			URL url = new URL(mContext.getString(R.string.url_path) + mType + ".txt"); 
			HttpURLConnection c = (HttpURLConnection) url.openConnection();
    	
			c.setRequestMethod("GET");
			c.setDoOutput(true);   
			c.connect();
			
			// Open FileOutputStream
			FileOutputStream fos;			
			fos = mContext.openFileOutput("file_" + mType, Context.MODE_PRIVATE);						
					
			// Receive data from network
			InputStream fis = c.getInputStream();    			
			byte[] buffer = new byte[fis.available()];  		
			while (fis.read(buffer) != -1) fos.write(buffer);   			
		
			fis.close(); 	
			fos.close();					
			
		} catch (Exception e2) {
			// Connection failed
			Log.e(TAG, e2.toString());
			Log.w(TAG,  mType + " download failed");
			
			Toast.makeText(mContext, "Verbindung zum Server fehlgeschlagen", Toast.LENGTH_SHORT).show();
			return false;
		}   		
		// Connection successful
		Log.w(TAG, mType + " download successful");   
		return true;
	}
}
