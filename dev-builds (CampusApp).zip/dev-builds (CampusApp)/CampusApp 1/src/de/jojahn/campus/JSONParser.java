package de.jojahn.campus;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.google.android.maps.GeoPoint;

public class JSONParser {
	private static final String TAG = "JSONParser";
	
	// Context and expected type of the invoking activity
	private Context mContext;		
	private String mType; 
	
	public JSONParser(Context context, String type) {
		mContext = context;	
		mType = type;
	}	
	
	// Parse JSON Object to NewsItem
	public ArrayList<NewsItem> parseNews(String category) {
		
		ArrayList<NewsItem> newsItems = new ArrayList<NewsItem>();		
		
		try {			
			// Establish InputStream connection
			InputStream fis = mContext.openFileInput("file_" + mType);
			Writer writer = new StringWriter();					
			char[] buffer = new char[fis.available()];			
			
			// Cancel parsing if file is empty			
			if (buffer.length == 0) {
				Log.w(TAG, mType + " is empty");
				return newsItems;
			}
			
			try {
				// Read FileInput in UTF-8 format
				BufferedReader reader = new BufferedReader(new InputStreamReader(fis, "UTF-8"));
				int n;
				while ((n = reader.read(buffer)) != -1) {
					writer.write(buffer, 0, n); 
				}				
			} finally { 
				fis.close();  
			}
			
			// Get JSON String
			String jsonText = writer.toString();			
			
			// Parse JSON String
			JSONArray entries = new JSONArray(jsonText);			
			for (int i = 0; i < entries.length(); i++) {
				JSONObject post = entries.getJSONObject(i); 						
				
				// Parse only requested news (category)
				if (category.equals(mContext.getString(R.string.all_news)) || category.equals(post.getString("category"))) {				
										
					// Date (year, month, day)
					JSONArray jsonDate = post.getJSONArray("date");
					int[] date = {
							jsonDate.getInt(0), 
							jsonDate.getInt(1), 
							jsonDate.getInt(2)
					};
				
					// New NewsItem
					NewsItem newsItem = new NewsItem(post.getString("category"), date, post.getString("title"), post.getString("description"), post.getString("url"));
												
					// Add NewsItem
					newsItems.add(newsItem);	
				}
			}			
			fis.close();	
		} 
		catch (Exception e) {
			// Parsing failed
			Log.e(TAG, e.toString());
			Log.w(TAG, mType + " parsing failed");
			Toast.makeText(mContext, mContext.getString(R.string.progress_failed), Toast.LENGTH_SHORT).show();
			return null;
		}		
		// Parsing successful
		Log.w(TAG, mType + " parsing successful");   
		return newsItems;
	}
	
	// Parse JSON Object to NewsCategories
	public ArrayList<String> parseNewsCategories() {
		
		ArrayList<String> newsCategories = new ArrayList<String>();		
		
		try {			
			// Establish InputStream connection
			InputStream fis = mContext.openFileInput("file_" + mType);
			Writer writer = new StringWriter();					
			char[] buffer = new char[fis.available()];			
			
			// Cancel parsing if file is empty			
			if (buffer.length == 0) {
				Log.w(TAG, mType + " is empty");
				return newsCategories;
			}
			
			try {
				// Read FileInput in UTF-8 format
				BufferedReader reader = new BufferedReader(new InputStreamReader(fis, "UTF-8"));
				int n;
				while ((n = reader.read(buffer)) != -1) {
					writer.write(buffer, 0, n); 
				}				
			} finally { 
				fis.close();  
			}
			
			// Get JSON String
			String jsonText = writer.toString();			
			
			// Parse JSON String
			JSONArray entries = new JSONArray(jsonText);			
			for (int i = 0; i < entries.length(); i++) {
				JSONObject post = entries.getJSONObject(i); 						
							
				// Add NewsCategorie
				if (!newsCategories.contains(post.getString("category"))) {
					newsCategories.add(post.getString("category"));
				}					
			}			
			fis.close();	
		} 
		catch (Exception e) {
			// Parsing failed
			Log.e(TAG, e.toString());
			Log.w(TAG, mType + " parsing failed");
			Toast.makeText(mContext, mContext.getString(R.string.progress_failed), Toast.LENGTH_SHORT).show();
			return null;
		}		
		// Parsing successful
		Log.w(TAG, mType + " parsing successful");   
		return newsCategories;
	}	
	
	// Parse JSON Object to MapItemList
	public ArrayList<MapOverlayItem> parseMap() {
		
		ArrayList<MapOverlayItem> mapOverlayItems = new ArrayList<MapOverlayItem>();		
		
		try {
			// Establish InputStream connection
			InputStream fis = mContext.openFileInput("file_" + mType);
			Writer writer = new StringWriter();					
			char[] buffer = new char[fis.available()];			
			
			// Cancel parsing if file is empty			
			if (buffer.length == 0) {
				Log.w(TAG, mType + " is empty");
				return mapOverlayItems;
			}
			
			try {
				// Read FileInput in UTF-8 format
				BufferedReader reader = new BufferedReader(new InputStreamReader(fis, "UTF-8"));
				int n;
				while ((n = reader.read(buffer)) != -1) {
					writer.write(buffer, 0, n); 
				}				
			} finally { 
				fis.close();  
			}	
			
			// Get JSON String
			String jsonText = writer.toString();			
			
			// Parse JSON String			
			JSONArray entries = new JSONArray(jsonText);			
			for (int i = 0; i < entries.length(); i++) {
				JSONObject post = entries.getJSONObject(i);						
				
				// GeoPoint 
				GeoPoint geoPoint = new GeoPoint((int) (post.getJSONArray("location").getDouble(0) * 1E6), (int) (post.getJSONArray("location").getDouble(1) * 1E6));
				
				// Extras
				String[] extraIntent = {
					post.getJSONArray("extra_intent").getString(0),	
					post.getJSONArray("extra_intent").getString(1),	
				};
				String[] extraTitel = {
					post.getJSONArray("extra_titel").getString(0),	
					post.getJSONArray("extra_titel").getString(1),	
				};
				
				// New MapOverlayItem
				MapOverlayItem mapOverlayItem = new MapOverlayItem(post.getInt("type"), geoPoint, post.getString("name"), post.getString("description"));
				mapOverlayItem.setExtra(extraIntent, extraTitel);
								
				// Add MapOverlayItem
				mapOverlayItems.add(mapOverlayItem);				
			}			
			fis.close();	
		} 
		catch (Exception e) {
			// Parsing failed
			Log.e(TAG, e.toString());
			Log.w(TAG, mType + " parsing failed"); 
			Toast.makeText(mContext, mContext.getString(R.string.progress_failed), Toast.LENGTH_SHORT).show();
			return null;
		}		
		// Parsing successful
		Log.w(TAG, mType + " parsing successful");   
		return mapOverlayItems;
	}
}
